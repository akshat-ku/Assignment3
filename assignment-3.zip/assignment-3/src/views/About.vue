<template>
  <div class="table-container">
    <table>
      <thead>
        <tr>
          <th>ID</th>
          <th>Name</th>
          <th>Age</th>
          <th>Purchase Item</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="item in tableData" :key="item.id">
          <td>{{ item.id }}</td>
          <td>{{ item.name }}</td>
          <td>{{ item.age }}</td>
          <td>{{ item.location }}</td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script>
export default {
  data() {
    return {
      tableData: [
        { id: 1, name: "Alice", age: 28, location: "Watch 1" },
        { id: 2, name: "Bob", age: 35, location: "Angel Watch " },
        { id: 3, name: "Charlie", age: 22, location: "7 watch" },
        { id: 4, name: "Alice", age: 28, location: "Watch 1" },
        { id: 5, name: "Bob", age: 35, location: "Angel Watch " },
        { id: 6, name: "Charlie", age: 22, location: "7 watch" },
        { id: 7, name: "Alice", age: 28, location: "Watch 1" },
        { id: 8, name: "Bob", age: 35, location: "Angel Watch " },
        { id: 9, name: "Charlie", age: 22, location: "7 watch" }

      ]
    };
  }
};
</script>

<style scoped>
/* Component-specific styles here */
.table-container {
  width: 100%;
}
table {
  width: 100%;
  border-collapse: collapse;
  border: 1px solid #ccc;
}
th, td {
  border: 1px solid #ccc;
  padding: 8px;
  text-align: left;
}
th {
  background-color: #f0f0f0;
}
</style>
