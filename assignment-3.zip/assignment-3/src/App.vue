<script setup>
import Navbar from './components/Navbar.vue';
</script>

<template>
<Navbar />
  <RouterView />
</template>


